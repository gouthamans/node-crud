const mongoose = require('mongoose');
const Schema = mongoose.Schema;
//const path =require('path');

	const ListSchema = new mongoose.Schema({

		First_Name:{
			type : String,
			required : true,
        	maxlength: 20
		},
		Last_Name:{
			type : String,
			required :true
		},
		Phone_No:{
			type : String,
			required :true,
			minlength:10,
			maxlength: 10

		},
		Email_ID:{
			type : String,
			required :true,
			unique: true
		},
		Password:{
			type : String,
			required :true,
			minlength:8,

		},
		// Profile_Img:{
		// 	type : String,
		// 	required :true
		// },
		Lat:{
			type : String,
			required :true
		},
		Lang:{
			type : String,
			required :true
		},
		City:{
			type : String,
			required :true
		},
		Country:{
			type : String,
			required :true
		},

	}); 
	const List  = mongoose.model('students', ListSchema);

	module.exports = List;
