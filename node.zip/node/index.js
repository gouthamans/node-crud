
const config = require('./config/config');


//db connection created in config files
 //const route = require('./routes/routes');


//  var express = require('express');
//  var mongoose = require('mongoose');
//  var bodyparser =require('body-parser');
//  var cors =require('cors');
//  var path =require('path');

//  var app = express();
//  const route = require('./routes/routes'); 
 
//  mongoose.connect('mongodb://sgoutham30:sgoutham30@ds057204.mlab.com:57204/gouthamongodb');


// mongoose.connection.on('connected',()=>{
// 	console.log('connected');
// }); 

// mongoose.connection.on('error',(err)=>{

// if(err){
// console.log('error');
// }
// console.log('connected to databae mongodb'+err);
// });

//  const port = 5000;

// app.use(cors()); //ading middleware

// app.use(bodyparser.json()); //get the input from client

// app.use(express.static(path.join(__dirname,'public')));

// app.use('/api',route);


// app.get('/',(req,res)=>{ 
// 	res.send('foobar');
// });

//  app.listen(port,()=>{
//  	console.log('server  started at port'+ port);
//  });

