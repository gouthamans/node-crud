var express = require('express');
var mongoose = require('mongoose');
var bodyparser = require('body-parser');
var cors = require('cors');
var path = require('path');

var app = express();
const route = require('../routes/routes');

mongoose.connect('mongodb://192.168.20.85/customers', { useNewUrlParser: true });
//mongoose.createConnection('mongodb://192.168.20.85/customers');
//mongoose.connect('mongodb://sgoutham30:sgoutham30@ds057204.mlab.com:57204/gouthamongodb');

//mongoose.connect('mongodb://sgoutham30:sgoutham30@ds057204.mlab.com:57204/gouthamongodb');
//mongodb://<dbuser>:<dbpassword>@ds057204.mlab.com:57204/gouthamongodb


mongoose.connection.on('connected', () => {
	console.log('connected');
});

mongoose.connection.on('error', (err) => {
	if (err) {
		console.log('error' + err);
	} else {
		console.log('connected to databae mongodb');
	}

});

const port = 4000;

app.use(cors()); //ading middleware
app.use(bodyparser.json()); //get the input from client
app.use(bodyparser.urlencoded({ extended: false }));

// app.use(function (req, res) {
	// res.setHeader('Content-Type', 'text/plain')
// })

//app.use(express.static(path.join(__dirname,'public')));

app.use('/api', route);


// app.get('/',(req,res)=>{ 
// 	res.send('foobar');
// });

app.listen(port, () => {

	console.log('server  started at port' + port);
});

