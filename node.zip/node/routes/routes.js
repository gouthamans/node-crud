const express = require('express');
const router = express.Router();
var multer = require('multer');
const validationResult = require('node-input-validator');
//var validator = require('validator');
//const check = require('express-validator/check').check;
//const validationResult = require('express-validator/check').validationResult;

const List = require('../models/list.js');
var path = require('path');


//console.log(List);
router.get('/listdata', (req, res, next) => {
	List.find(function (err, data) {
		res.json(data);
	});
});


router.get('/listdataonerow/:id', (req, res, next) => {
	List.find({ _id: req.params.id }, function (err, data) {
		res.json(data);
	});
});

router.get('/login/:First_Name/:password', (req, res, next) => {  ///:password
	List.find({ First_Name: req.params.First_Name, password: req.params.password }, function (err, data) { //,password:req.params.password

		if (data.length == 1) {
			res.json({ msg: "login Successfully" });
		} else {
			res.json({ msg: "Error in login" + err });
		}
		//res.json(data);
		//console.log(data.length);

	});
});

router.post('/add', (req, res, next) => {

	var Lists = new List({
		First_Name: req.body.First_Name,
		Last_Name: req.body.Last_Name,
		Phone_No: req.body.Phone_No,
		Email_ID: req.body.Email_ID,
		Password: req.body.Password,
		Profile_Img: req.body.Profile_Img,
		Lat: req.body.Lat,
		Lang: req.body.Lang,
		City: req.body.City,
		Country: req.body.Country
	});


	console.log('testtttt');
	let validator = new validationResult(req.body, {
		Email_ID: 'required|email'
		//password: 'required'
	});

	validator.check().then(function (matched) {
		console.log('testbbbbb');
		if (!matched) {
			res.status(422).send(validator.errors);
		}
	});
	Lists.save((err, listmodel) => {
		if (err) {
			res.json({ msg: "Failed  to add" + err });
		} else {
			res.json({ msg: " Added Successfully" });
		}
	});

});


router.put('/update/:id', (req, res, next) => {
	//console.log(List);
	var Lists = new List({
		First_Name: req.body.First_Name,
		last_name: req.body.last_name,
		phone_no: req.body.phone_no,
		password: req.body.password
	});
	List.findById(req.params.id).then(post => {

		post.First_Name = req.body.First_Name;
		post.password = req.body.password;

		post.save().then(post => {
			res.send({ msg: "success" });
		});
	});
});


// var newvalues = { $set: {First_Name: req.body.First_Name } };
// mongoose.connection("students").updateOne({"_id":req.params.id},newvalues, function(err, res) {
//   if (err) throw err;
//   console.log("1 document updated");
//   db.close();
// });
//});


router.delete('/delete/:id', (req, res, next) => {
	console.log(req.params.id);
	List.remove({ _id: req.params.id }, function (err, result) {
		if (err) {
			res.json(err);
		} else {
			res.json(result);
		}
	});
});


//file upload 

// router.post('/upload',upload.any(),function(req,res,next){
// 	res.send({msg:"success"});
// });


var storage = multer.diskStorage({
	destination: function (req, file, callback) {
		callback(null, 'public/uploads/');
	},
	filename: function (req, file, callback) {

		var ext = path.extname(file.originalname);
		console.log(ext);
		callback(null, file.fieldname + '-' + Date.now() + '.' + ext);
	}
});
var upload = multer({ storage: storage }).array('userPhoto', 2);//single('userPhoto');

router.post('/upload', function (req, res) {
	upload(req, res, function (err) {
		if (err) {
			return res.end("Error uploading file.");
		}
		res.end("File is uploaded");
	});
});
module.exports = router;





